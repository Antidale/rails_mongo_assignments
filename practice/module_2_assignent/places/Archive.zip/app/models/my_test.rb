class MyTest

  def self.test
    photo = Photo.all.first
  end
end
